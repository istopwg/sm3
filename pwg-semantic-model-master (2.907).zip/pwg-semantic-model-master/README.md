# Semantic-Model
This is a semantic data model of imaging systems - print, scan, fax, copy in a local, enterprise, mobile and cloud environment. It includes 3D printing. 
